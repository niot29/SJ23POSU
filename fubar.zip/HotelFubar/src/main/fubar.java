package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import jdk.internal.org.jline.reader.ParsedLine;

public class fubar {

	static ArrayList<String> cutomerInfo;
	static ArrayList<String> roomInfo;
	static ArrayList<String> bookingInfo;

	static HashMap<Integer, ArrayList<String>> cuntomerDb = new HashMap<Integer, ArrayList<String>>();
	static HashMap<Integer, ArrayList<String>> roomDb = new HashMap<Integer, ArrayList<String>>();
	static HashMap<Integer, ArrayList<String>> bookingDb = new HashMap<Integer, ArrayList<String>>();

	private static void mainScreen(String[] menu) {
		try {
			final String os = System.getProperty("os.name");
			// System.out.println(os);
			if (os.contains("Windows")) {
				String[] cls = new String[] { "cmd.exe", "/c", "cls" };
				Runtime.getRuntime().exec(cls);
			} else {
				System.out.print("\033[H\033[2J");
				System.out.flush();
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}

		String leftAlignFormat = "|   %-3d | %-25s |%n";
		System.out.println("");
		System.out.println("");
		System.out.format("+=======+===========================+%n");
		System.out.format("| Menu  | Descriptions              |%n");
		System.out.format("+-------+---------------------------+%n");
		for (int i = 0; i < menu.length; i++) {
			System.out.format(leftAlignFormat, i + 1, menu[i]);
		}
		System.out.format("+-------+---------------------------+%n");
		System.out.print("Navigate from menu, select option in menu: ");

	}

	private static void customerScreen() {

		String leftAlignFormat = "|   %-3d | %-25s |%n";
		System.out.println("");
		System.out.println("");
		System.out.format("+-------+---------------------------+%n");
		System.out.format("| Customer no  | Customer info              |%n");
		System.out.format("+-------+---------------------------+%n");

		for (int cKey : cuntomerDb.keySet()) {
			System.out.format(leftAlignFormat, cKey, cuntomerDb.get(cKey));
		}

		System.out.format("+-------+---------------------------+%n");
		System.out.format("*************************************%n");
		System.out.format("*************************************%n");
	}

	private static void roomScreen(int listType) {

		String leftAlignFormat = "|   %-3d | %-25s |%n";
		System.out.println("");
		System.out.println("");
		System.out.format("+-------+---------------------------+%n");
		System.out.format("| Room no  | Room info              |%n");
		System.out.format("+-------+---------------------------+%n");

		switch (listType) {
		case 1:
			for (int cKey : roomDb.keySet()) {
				System.out.format(leftAlignFormat, cKey, roomDb.get(cKey));
			}
			break;
		case 2:

			for (int cKey : roomDb.keySet()) {

				ArrayList<String> rList = roomDb.get(cKey);
				ArrayList<String> newRoomList = new ArrayList<String>();
				if (rList.get(2).equals("1")) {
					newRoomList.addAll(rList);
					System.out.format(leftAlignFormat, cKey, newRoomList);
				}
			}
			break;
		default:
			break;

		}

		System.out.format("+-------+---------------------------+%n");
		System.out.format("*************************************%n");
		System.out.format("*************************************%n");
	}

	private static void bookingScreen(int listType) {
		String leftAlignFormat = "| %-5s | %-25s |%n";
		System.out.println("");
		System.out.println("");
		System.out.format("+-------+---------------------------+%n");
		System.out.format("| Booning no  | Booking info        |%n");
		System.out.format("+-------+---------------------------+%n");

		switch (listType) {
		case 1:
			for (int cKey : bookingDb.keySet()) {
				System.out.format(leftAlignFormat, cKey, bookingDb.get(cKey));
			}
			break;
		case 2:

			for (int cKey : bookingDb.keySet()) {

				ArrayList<String> rList = bookingDb.get(cKey);
				ArrayList<String> bList = new ArrayList<String>();
				if (rList.get(6).equals("1")) {
					bList.addAll(rList);
					System.out.format(leftAlignFormat, cKey, bList);
				}
			}

			break;
		default:
			break;

		}
		System.out.format("+-------+---------------------------+%n");
		System.out.format("*************************************%n");
		System.out.format("*************************************%n");
	}

	private static void setDbColumn() {
		cutomerInfo = new ArrayList<String>();
		cutomerInfo.add("First Name: ");
		cutomerInfo.add("Last Name: ");
		cutomerInfo.add("Email: ");
		cutomerInfo.add("Address: ");
		cutomerInfo.add("Phone: ");

		roomInfo = new ArrayList<String>();
		roomInfo.add("Type (Bed in the room): ");
		roomInfo.add("Description: ");
		roomInfo.add("Status: ");
		roomInfo.add("Booking no: ");
		roomInfo.add("Customer no: ");
		roomInfo.add("Booking end date: ");

		bookingInfo = new ArrayList<String>();
		bookingInfo.add("Room no: ");
		bookingInfo.add("Cutomer: ");
		bookingInfo.add("Booking start date (YYYY-MM-DD): ");
		bookingInfo.add("Booking end date (YYYY-MM-DD): ");
		bookingInfo.add("Total nigth: ");
		bookingInfo.add("Description: ");
		bookingInfo.add("Status: ");

		// upload data to map

		HashMapFromTextFile("Booking.txt", bookingDb);
		HashMapFromTextFile("Cutomer.txt", cuntomerDb);
		HashMapFromTextFile("Room.txt", roomDb);

	}

	private static void mainMenu() {
		String[] menu = { "Booking", "MgnRoom", "MgnCustom", "Exit" };
		mainScreen(menu);

		String mSelection = "";
		Scanner mainInput = new Scanner(System.in);
		mSelection = mainInput.nextLine();
		while (!mSelection.equals(Integer.toString(menu.length))) {

			switch (mSelection) {
			case "1":
				bookingHandler();
				break;
			case "2":
				roomManager();
				break;
			case "3":
				customerManager();
				break;
			case "4":
				System.out.println("Exit");
				break;
			default:
				// mainScreen();
				System.out.print("Your chouse is incorrect. Pleace try again: ");
			}
			mainScreen(menu);
			mSelection = mainInput.nextLine();

		}
		mainInput.close();
		mainScreen(menu);
	}

	private static void saveToFile(String dbFile) {

		String outputFilePath = null;
		BufferedWriter bf = null;
		Set<Entry<Integer, ArrayList<String>>> mapEntrySet = null;
		switch (dbFile) {
		case "booking":
			outputFilePath = "Booking.txt";
			mapEntrySet = bookingDb.entrySet();
			break;
		case "customer":
			outputFilePath = "Cutomer.txt";
			mapEntrySet = cuntomerDb.entrySet();
			break;
		case "room":
			outputFilePath = "Room.txt";
			mapEntrySet = roomDb.entrySet();
			break;
		default:
			break;
		}
		File file = new File(outputFilePath);
		try {

			// create new BufferedWriter for the output file
			bf = new BufferedWriter(new FileWriter(file));

			// iterate map entries
			// for (Map.Entry<Integer, ArrayList<String>> entry : cuntomerDb.entrySet()) {
			for (Map.Entry<Integer, ArrayList<String>> entry : mapEntrySet) {

				// put key and value separated by a colon
				bf.write(entry.getKey() + ":" + entry.getValue());

				// new line
				bf.newLine();
			}

			bf.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			try {

				// always close the writer
				bf.close();
			} catch (Exception e) {
			}
		}
	}

	private static void HashMapFromTextFile(String filePath, HashMap<Integer, ArrayList<String>> db) {
		// String filePath = "Cutomer.txt";
		String[] strArray = null;
		BufferedReader br = null;

		try {

			// create file object
			File file = new File(filePath);

			// create BufferedReader object from the File
			br = new BufferedReader(new FileReader(file));

			String line = null;

			// read file line by line
			while ((line = br.readLine()) != null) {

				// split the line by :
				String[] parts = line.split(":");

				// first part is name, second is number
				int mKey = Integer.parseInt(parts[0].trim());
				// System.out.println("Key: " + mKey);
				String regex1 = ",";
				Pattern ptr1 = Pattern.compile(regex1);

				strArray = ptr1.split(parts[1]);
				ArrayList<String> mList = new ArrayList<String>();
				for (int i = 0; i < strArray.length; i++) {

					strArray[i] = strArray[i].replace("[", "");
					strArray[i] = strArray[i].replace("]", "");
					// strArray[i] = strArray[i].replace(" ", "");
					mList.add(strArray[i].trim());
				}
				db.put(mKey, mList);

			}
		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("System cant open som data import file: ." + filePath);
		} finally {

			// Always close the BufferedReader
			if (br != null) {
				try {
					br.close();
				} catch (Exception e) {
				}
				;
			}
		}

	}

	private static int customerManagerAddNewCutomer() {
		int custId = 1;
		try {
			custId = cuntomerDb.entrySet().stream().reduce((one, two) -> two).get().getKey();
		} catch (Exception e) {
			// custId = 1;
			// e.printStackTrace();
		}
		Scanner input = new Scanner(System.in);
		ArrayList<String> inputList = new ArrayList<String>();
		for (String customer_str : cutomerInfo) {
			System.out.print(customer_str);
			String inputValue = "";
			inputValue = input.nextLine();
			inputList.add(inputValue);
		}

		cuntomerDb.put(custId + 1, inputList);

		// Sort HasMap by key
		HashMap<Integer, ArrayList<String>> temp = cuntomerDb.entrySet().stream()
				.sorted((i1, i2) -> i1.getKey().compareTo(i2.getKey()))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

		// BUGG CAST EXEPTION WHEN ADDING MER CUTOMER AND SCANNER IS CLOSE.
		// input.close();
		return custId + 1;
	}

	private static void customerManagerUpdateCutomer() {
		Scanner input3 = new Scanner(System.in);
		Scanner scanValue = new Scanner(System.in);
		System.out.print("Udpdate cutmer with ID: ");
		int cuId = input3.nextInt();
		if (cuntomerDb.containsKey(cuId)) {
			String[] custInfo = cutomerInfo.toArray(new String[cutomerInfo.size()]);
			mainScreen(custInfo);
			System.out.println("With field would you lika to update:");

			ArrayList<String> values = cuntomerDb.get(cuId);

			int updateIndex = input3.nextInt();
			System.out.println("Update customer " + custInfo[updateIndex - 1] + ": " + values.get(updateIndex - 1));
			System.out.print("Input new information: ");
			String newValuse = scanValue.nextLine();
			values.set(updateIndex - 1, newValuse);
			cuntomerDb.put(cuId, values);
		}
		// System.out.println(cuntomerDb.containsKey(cuId));

	}

	private static void customerManagerremoveCutomer() {
		Scanner input4 = new Scanner(System.in);
		Scanner custValue = new Scanner(System.in);
		customerScreen();
		System.out.print("With Cutomer would you lika to remove: ");
		int rCuId = input4.nextInt();
		customerScreen();
		if (cuntomerDb.containsKey(rCuId)) {
			String[] custInfo = cutomerInfo.toArray(new String[cutomerInfo.size()]); //
			String[] values = cuntomerDb.get(rCuId).toArray(new String[cutomerInfo.size()]);
			System.out.print("Customer: " + values[0] + " " + values[1]);
			System.out.print("Verified y/n:");
			String confirme = custValue.nextLine();
			switch (confirme) {
			case "y":
				cuntomerDb.remove(rCuId);
				customerScreen();
				break;
			case "Y":
				cuntomerDb.remove(rCuId);
				customerScreen();
				break;
			default:
				break;
			}

		} else {
			System.out.println("This ID dosn't exist try again.");
		}
	}

	public static void customerManager() {
		String[] customerMenu = { "List Cutomer", "Add new Cutomer", "Update Custom Informatiom", "Remove cutomer",
				"Exit" };
		mainScreen(customerMenu);

		String mSelection = "";
		int skipp = 1;
		Scanner mainInput = new Scanner(System.in);
		mSelection = mainInput.nextLine();
		while (!mSelection.equals(Integer.toString(customerMenu.length))) {

			switch (mSelection) {
			case "1":
				skipp = 1;
				customerScreen();
				mainScreen(customerMenu);
				break;
			case "2":
				System.out.println("Fill in customer information:");
				customerManagerAddNewCutomer();
				saveToFile("customer");
				mSelection = "1";
				skipp = 0;
				break;
			case "3":
				customerScreen();
				customerManagerUpdateCutomer();
				saveToFile("customer");
				mSelection = "1";
				skipp = 0;
				break;

			case "4":
				customerManagerremoveCutomer();
				saveToFile("customer");
				mSelection = "1";
				skipp = 0;
				break;
			case "5":
				break;
			default:
				mainScreen(customerMenu);
				System.out.print("Your chouse is incorrect. Pleace try again: ");
				mSelection = "0";
				break;

			}
			if (skipp != 0) {
				mSelection = mainInput.nextLine();
			}

		}

		mainMenu();

	}

	private static int roomManagerAddNewRoom() {
		int roomId5 = 1;
		try {
			roomId5 = roomDb.entrySet().stream().reduce((one, two) -> two).get().getKey();
		} catch (Exception e) {
			// custId = 1;
			// e.printStackTrace();
		}
		Scanner input = new Scanner(System.in);
		ArrayList<String> inputList = new ArrayList<String>();
		for (String room_str : roomInfo) {
			String inputValue = "";
			if (room_str.equals("Status: ")) {
				System.out.print("Room is bookable (y/n): ");
				inputValue = input.nextLine();
				if (inputValue.equals("y")) {
					inputValue = "1";
				} else {
					inputValue = "0";
				}
			} else if (room_str.equals("Booking no: ")) {
				break;
			} else {
				System.out.print(room_str);
				inputValue = input.nextLine();
			}

			inputList.add(inputValue);
		}
		roomDb.put(roomId5 + 1, inputList);
		return roomId5 + 1;

	}

	private static void roomManagerRemoveRoom() {
		Scanner input4 = new Scanner(System.in);
		System.out.println("Which room would you like to take out of :");
		int roomId4 = input4.nextInt();
		if (roomDb.containsKey(roomId4)) {
			// String[] custInfo = roomInfo.toArray(new String[roomInfo.size()]);
			ArrayList<String> values = roomDb.get(roomId4);
			int index = roomInfo.indexOf("Status: ");
			values.set(index, "X");
			roomDb.put(roomId4, values);
		}
	}

	private static void roomManagerUpdateRoom() {
		Scanner input3 = new Scanner(System.in);
		Scanner scanValue = new Scanner(System.in);
		System.out.print("Udpdate cutmer with ID: ");
		int roomId = input3.nextInt();
		if (roomDb.containsKey(roomId)) {
			String[] rInfo = roomInfo.toArray(new String[roomInfo.size()]);
			mainScreen(rInfo);
			System.out.println("With field would you lika to update:");

			ArrayList<String> values = roomDb.get(roomId);

			int updateIndex = input3.nextInt();
			if (values.size() < updateIndex) {
				System.out.println("Cant update this value");

			}
			System.out.println("Update customer " + rInfo[updateIndex - 1] + ": " + values.get(updateIndex - 1));
			System.out.print("Input new information: ");
			String newValuse = scanValue.nextLine();

			values.set(updateIndex - 1, newValuse);
			roomDb.put(roomId, values);
		}
	}

	private static void roomManager() {
		String[] roomMenu = { "List All", "List Free", "Update room", "Remove room", "Add new room", "Exit" };
		mainScreen(roomMenu);
		String mSelection = "";
		int skipp = 1;
		Scanner mainInput = new Scanner(System.in);
		mSelection = mainInput.nextLine();
		while (!mSelection.equals(Integer.toString(roomMenu.length))) {

			switch (mSelection) {
			case "1":
				skipp = 1;
				roomScreen(1);
				mainScreen(roomMenu);
				break;
			case "2":
				skipp = 1;
				roomScreen(2);
				mainScreen(roomMenu);
				break;
			case "3":
				roomScreen(1);
				roomManagerUpdateRoom();
				saveToFile("room");
				mSelection = "1";
				skipp = 0;
				break;

			case "4":
				roomScreen(1);
				roomManagerRemoveRoom();
				saveToFile("room");
				mSelection = "1";
				skipp = 0;
				break;
			case "5":
				System.out.println("Fill in room information:");
				roomManagerAddNewRoom();
				saveToFile("room");
				mSelection = "1";
				skipp = 0;
				break;
			case "6":
				break;
			default:
				break;
			}
			if (skipp != 0) {
				mSelection = mainInput.nextLine();
			}

		}

	}

	private static int bookingHandlerAddNewBooking() {

		roomScreen(2);
		int bId;
		LocalDate firstDate = null;
		LocalDate secondDate = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		try {
			bId = bookingDb.entrySet().stream().reduce((one, two) -> two).get().getKey();
		} catch (Exception e) {
			bId = 1;
			// e.printStackTrace();
		}
		Scanner input = new Scanner(System.in);
		Scanner switchInput = new Scanner(System.in);
		ArrayList<String> inputList = new ArrayList<String>();
		for (String str : bookingInfo) {
			String inputValue = "";
			String choisetValue = "";
			int cuID;
			switch (str) {
			case "Room no: ":
				System.out.print(str);
				inputValue = input.nextLine();
				int eKey = Integer.parseInt(inputValue);
				ArrayList<String> values = roomDb.get(eKey);
				values.set(3 - 1, "0");
				roomDb.put(eKey, values);
				break;
			case "Cutomer: ":
				System.out.print("List Cutomer in sytem (y/n): ");
				choisetValue = switchInput.nextLine();
				if (choisetValue.equals("y")) {
					customerScreen();
					System.out.print("Add new Cutomer (y/n): ");
					choisetValue = switchInput.nextLine();
					if (choisetValue.equals("y")) {
						cuID = customerManagerAddNewCutomer();
						System.out.println(cuID);
						inputValue = String.valueOf(cuID);
					} else {
						System.out.print("Add cutomer no: ");
					}

				} else {
					System.out.print("Add cutomer no: ");
				}
				inputValue = input.nextLine();
				break;
			case "Status: ":
				inputValue = "1";
				break;
			case "Booking start date (YYYY-MM-DD): ":
				System.out.print(str);
				inputValue = "";

				while (inputValue.isEmpty()) {
					String startDate = input.nextLine();

					try {

						firstDate = LocalDate.parse(startDate, formatter);
						// System.out.println(firstDate);
						inputValue = firstDate.toString();

					} catch (Exception e) {
						System.out.print("Wrong format on date. Need to bee number format: ");
						inputValue = "";
						// e.printStackTrace();
					}

				}
				System.out.println(inputValue);
				break;
			case "Booking end date (YYYY-MM-DD): ":
				System.out.print(str);
				inputValue = "";
				while (inputValue.isEmpty()) {
					String startDate = input.nextLine();

					try {
						secondDate = LocalDate.parse(startDate, formatter);
						inputValue = secondDate.toString();
					} catch (Exception e) {
						System.out.print("Wrong format on date. Need to bee number format: ");
						inputValue = "";
						// e.printStackTrace();
					}

				}
				System.out.println(inputValue);
				break;
			case "Total nigth: ":
				long days = ChronoUnit.DAYS.between(firstDate, secondDate);
				System.out.println("Total length of stay: " + days);
				inputValue = String.valueOf(days);
				break;
			default:
				System.out.print(str);
				inputValue = input.nextLine();

				break;
			}
			inputList.add(inputValue);
		}

		bookingDb.put(bId + 1, inputList);
		return bId + 1;
	}

	private static void bookingHandlerCancelBooking() {
		bookingScreen(2);
		Scanner input = new Scanner(System.in);
		Scanner custValue = new Scanner(System.in);
		System.out.print("Cancel booking on booking no: ");
		int boid = input.nextInt();
		if (bookingDb.containsKey(boid)) {
			ArrayList<String> values = bookingDb.get(boid);
			int index = bookingInfo.indexOf("Status: ");
			System.out.print("Verified remove booning y/n:");
			String confirme = custValue.nextLine();
			
			
			int eKey = boid;
			ArrayList<String> roomList = roomDb.get(eKey);
			roomList.set(3 - 1, "1");
			
			switch (confirme) {
			case "y":
				roomList.set(3 - 1, "1");
				roomDb.put(eKey, values);
				
				values.set(index, "0");
				bookingDb.put(boid, values);
				
				
				
				break;
			case "Y":
				roomList.set(3 - 1, "1");
				roomDb.put(eKey, values);
				
				values.set(index, "0");
				bookingDb.put(boid, values);
				
				break;
			default:
				break;
			}
		}
	}

	private static void bookingHandler() {
		String[] bookingMenu = { "Book", "List All Booking", "List Free Room", "Cancel reservation", "Search date",
				"Exit" };
		mainScreen(bookingMenu);
		String mSelection = "";
		Scanner mainInput = new Scanner(System.in);
		mSelection = mainInput.nextLine();
		int skipp = 1;
		while (!mSelection.equals(Integer.toString(bookingMenu.length))) {
			switch (mSelection) {
			case "1":
				// customerScreen();
				bookingHandlerAddNewBooking();
				saveToFile("booking");
				saveToFile("room");
				saveToFile("customer");
				// mSelection = "1";
				skipp = 1;
				break;
			case "2":
				bookingScreen(2);
				mainScreen(bookingMenu);
				skipp = 1;
				break;
			case "3":
				skipp = 1;
				roomScreen(2);
				mainScreen(bookingMenu);
				break;
			case "4":
				bookingHandlerCancelBooking();
				saveToFile("booking");
				saveToFile("room");
				saveToFile("customer");
				mSelection = "2";
				break;
			case "5":
				skipp = 1;
				break;
			case "6":
				break;
			default:
				mainScreen(bookingMenu);
				System.out.print("Your chouse is incorrect. Pleace try again: ");
				mSelection = "0";
				break;
			}

			if (skipp != 0) {
				mSelection = mainInput.nextLine();
			}

		}
	}

	public static void main(String[] args) {

		setDbColumn();
		// System.out.println(cuntomerDb);
		mainMenu();

		// addcutomerInfo();
	}

}
