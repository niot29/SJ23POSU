package org.CustomerManager.DBService;

import org.CustomerManager.Model.Address;

import java.util.List;

public class AddressDBHandler implements AddressDBInterface{
    @Override
    public int create(Address address) {

        return 0;
    }

    @Override
    public Address getAddressById(int id) {
        return null;
    }

    @Override
    public List<Address> ListAddress() {
        return null;
    }

    @Override
    public Address updateCustomer(Address address) {
        return null;
    }

    @Override
    public void deleteAddressById(int id) {

    }
}
