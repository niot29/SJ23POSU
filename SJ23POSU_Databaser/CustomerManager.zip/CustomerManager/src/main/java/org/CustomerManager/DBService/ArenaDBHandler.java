package org.CustomerManager.DBService;

import org.CustomerManager.Model.Arena;

import java.util.List;

public class ArenaDBHandler implements ArenaDBInterface{
    @Override
    public int create(Arena arena) {
        return 0;
    }

    @Override
    public Arena getArenaById(int id) {
        return null;
    }

    @Override
    public List<Arena> ListArena() {
        return null;
    }

    @Override
    public Arena updateArena(Arena arena) {
        return null;
    }

    @Override
    public void deleteArenaById(int id) {

    }
}
