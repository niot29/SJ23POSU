package org.CustomerManager.DBService;

import org.CustomerManager.Model.Concert;
import java.util.List;

public class ConcertDBHandler implements ConsertDBInterface{
    @Override
    public int create(Concert consert) {



        return 0;
    }

    @Override
    public Concert getConsertById(int id) {
        return null;
    }

    @Override
    public List<Concert> ListConsert() {
        return null;
    }

    @Override
    public Concert updateConserta(Concert consert) {
        return null;
    }

    @Override
    public void deleteConsertById(int id) {

    }
}
