SJ23POSU Introduktion till JAVA

github: https://github.com/niot29/SJ23POSU

Bokning system som tillhado h�ller kundbokning. System funktioner:

+=======+===========================+
| Menu  | Descriptions              |
+-------+---------------------------+
|   1   | BOOKING                   |
|   2   | MANAGER ROOM              |
|   3   | MANAGER CUTOMER           |
|   4   | Exit                      |
+-------+---------------------------+
Navigate from menu, select option in menu:


BOOKING - Hantera bokningar (l�gga till, tabort - bookingar, s�kning av boknings information)
+=======+===========================+
| Menu  | Descriptions              |
+-------+---------------------------+
|   1   | Book                      |
|   2   | List All Booking          |
|   3   | List Free Room            |
|   4   | Cancel reservation        |
|   5   | Search By Booking no      |
|   6   | Search By Date            |
|   7   | Exit                      |
+-------+---------------------------+
Navigate from menu, select option in menu:


MANAGER ROOM - Hantera rum (lista p� lediga rum, l�gga till loch uppdatera rum, samt tar rum ur drift)
+=======+===========================+
| Menu  | Descriptions              |
+-------+---------------------------+
|   1   | List All                  |
|   2   | List Free                 |
|   3   | Update room               |
|   4   | Remove room               |
|   5   | Add new room              |
|   6   | Exit                      |
+-------+---------------------------+
Navigate from menu, select option in menu:


MANAGER CUTOMER - Hanter kund information (l�gga till kund och dess kontat info, samt tarbort info)
+=======+===========================+
| Menu  | Descriptions              |
+-------+---------------------------+
|   1   | List Cutomer              |
|   2   | Add new Cutomer           |
|   3   | Update Custom Informatiom |
|   4   | Remove cutomer            |
|   5   | Exit                      |
+-------+---------------------------+
Navigate from menu, select option in menu:


S�ka booking och detalj information Under huvud "BOOKING" s� finns det m�jlighet att s� efter lediga rum mellan booking datum. system presenterar de tillg�nliga rum som g�r att boka under den agivna tids perioden.

S�ka delja information om bokning, kan �ven g�ra under huvud "BOOKING". Ange booknings nr. d� resenteras dokning, rum information dvs vilken rum och typ som �r relaterad till bokningen samt kund information. bdbb564cebae1b73db9d363f7d6c6b8a.png

System anv�nder java "HasMap" som inmemory databas lagring. Och persisten lagring s� lagras informationen i txt-filer. Det finns 3st filer som relaterad till databas infromation

cutomer.txt (kund information)
booking.txt (boknings information)
room.txt (rum information)
Informationen i txt laddas in vid uppstart av programet. (Om filen inte finns s� informerar systemen. Programet funkar som vanligt, vid updatering av inmemory database "HasMap" s� kommer filen att automatisk skapas och lagra data).

Applikationen har metoder som presenterar informationen i tabeller med ASCII grafik. metoder: screeenXXXX.

BUGG:

s�ka bookning som inte finns p� bokning nr
s�ka bookning p� datum som inte finns
skal inte kunna l�gga till kund som inte finn. fin spars �nd� inte